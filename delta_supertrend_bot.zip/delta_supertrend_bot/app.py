import streamlit as st

st.set_page_config(page_title="Delta Supertrend Bot", layout="wide")
st.title("Delta Supertrend Trailing + Fixed SL Bot")

st.write("Use the left sidebar to open **Dashboard** or **Account** pages.")
st.info("Tip: Start on Dashboard, click 'Start Bot' to begin streaming candles + trading.")
