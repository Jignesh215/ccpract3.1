from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from core.bot_runtime import BotRuntime
from core.candle_store import CandleStore
from core.config import load_settings
from core.indicators import supertrend

API_LOG_PATH = Path(__file__).resolve().parents[1] / "api_call.log"

# Timeframe options: label → minutes
TF_OPTIONS: dict[str, int] = {"1m": 1, "30m": 30, "45m": 45, "1h": 60, "4h": 240}

# ── small helpers ──────────────────────────────────────────────────────────────

def _fmt_ts(ts: int | None) -> str:
    if not ts:
        return "-"
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def _tail_log(path: Path, lines: int = 40) -> str:
    if not path.exists():
        return "api_call.log will appear after the first Delta REST or WebSocket event."
    content = path.read_text(encoding="utf-8", errors="replace").splitlines()
    return "\n".join(content[-lines:]) if content else "api_call.log is empty."


def _status_variant(text: str) -> str:
    low = text.lower()
    if any(t in low for t in ("error", "failed", "closed")):
        return "error"
    if any(t in low for t in ("live:", "subscribed", "running", "trade executed")):
        return "success"
    return "warning"


def _build_chart(
    resampled_df: pd.DataFrame,
    trades: pd.DataFrame,
    st_factor: float,
    atr_period: int,
    tf_label: str,
) -> go.Figure:
    """
    OHLC candlestick chart with SuperTrend line overlay and BUY/SELL/EXIT markers.

    Parameters
    ----------
    resampled_df : already-resampled OHLCV DataFrame (ts, open, high, low, close, volume)
    trades       : trade history DataFrame from TradeStore
    st_factor    : SuperTrend multiplier
    atr_period   : ATR period for SuperTrend computation
    tf_label     : human-readable timeframe string shown in the chart title
    """
    if resampled_df is None or resampled_df.empty:
        fig = go.Figure()
        fig.update_layout(
            title=f"No {tf_label} data yet — start the bot and press Refresh",
            height=520,
            template="plotly_dark",
        )
        return fig

    has_enough_for_st = len(resampled_df) >= atr_period + 2

    if has_enough_for_st:
        df_st = supertrend(resampled_df.copy(), factor=st_factor, atr_period=atr_period)
    else:
        df_st = resampled_df.copy()
        df_st["supertrend"] = float("nan")
        df_st["direction"]  = 0

    x_vals = [datetime.fromtimestamp(int(ts)) for ts in df_st["ts"]]

    bull_mask = df_st["direction"] == 1
    bear_mask = df_st["direction"] == -1

    fig = go.Figure()

    # ── OHLC candle bars ──────────────────────────────────────────────────────
    fig.add_trace(go.Candlestick(
        x=x_vals,
        open=df_st["open"],
        high=df_st["high"],
        low=df_st["low"],
        close=df_st["close"],
        name=f"{tf_label} Candles",
        increasing_line_color="#26a69a",
        decreasing_line_color="#ef5350",
    ))

    # ── SuperTrend: bullish segment (green, plotted below price) ─────────────
    if bull_mask.any():
        bull_x = [x_vals[i] for i in range(len(x_vals)) if bull_mask.iloc[i]]
        bull_y = df_st.loc[bull_mask, "supertrend"].values
        fig.add_trace(go.Scatter(
            x=bull_x,
            y=bull_y,
            mode="lines",
            name="ST Bullish",
            line=dict(color="#00e676", width=2),
        ))

    # ── SuperTrend: bearish segment (red, plotted above price) ───────────────
    if bear_mask.any():
        bear_x = [x_vals[i] for i in range(len(x_vals)) if bear_mask.iloc[i]]
        bear_y = df_st.loc[bear_mask, "supertrend"].values
        fig.add_trace(go.Scatter(
            x=bear_x,
            y=bear_y,
            mode="lines",
            name="ST Bearish",
            line=dict(color="#ff1744", width=2),
        ))

    # ── Trade entry/exit markers ──────────────────────────────────────────────
    if not trades.empty:
        for _, tr in trades.iterrows():
            action = str(tr.get("action", ""))
            price  = float(tr.get("price", 0))
            ts_tr  = int(tr.get("ts", 0))
            if not ts_tr:
                continue
            x_tr   = datetime.fromtimestamp(ts_tr)
            marker_sym = ("triangle-up"   if action == "BUY"  else
                          "triangle-down" if action == "SELL" else
                          "circle"        if "EXIT" in action else "x")
            colour = ("#00e676" if action == "BUY"  else
                      "#ff1744" if action == "SELL" else
                      "#ffd600" if "EXIT" in action else "#9e9e9e")
            fig.add_trace(go.Scatter(
                x=[x_tr],
                y=[price],
                mode="markers",
                name=action,
                marker=dict(
                    symbol=marker_sym,
                    size=14,
                    color=colour,
                    line=dict(width=1, color="#000"),
                ),
                hovertext=f"{action} @ {price:.2f}<br>{tr.get('reason', '')}",
                hoverinfo="text",
                showlegend=False,
            ))

    st_note = f"factor={st_factor}, ATR={atr_period}" if has_enough_for_st else f"accumulating bars ({len(resampled_df)}/{atr_period + 2} needed for ST)"
    fig.update_layout(
        title=f"{tf_label} OHLC Bars + SuperTrend  ({st_note})",
        xaxis_title="Time",
        yaxis_title="Price (USDT)",
        height=540,
        xaxis_rangeslider_visible=False,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        template="plotly_dark",
        margin=dict(l=10, r=10, t=55, b=10),
        uirevision="sol_chart",   # preserve zoom/pan across Streamlit reruns
    )
    return fig


# ── state bootstrap ────────────────────────────────────────────────────────────

def _ensure_state() -> None:
    if "settings" not in st.session_state:
        st.session_state.settings = load_settings()
    if "runtime" not in st.session_state:
        st.session_state.runtime = BotRuntime(st.session_state.settings)
    # Shared CandleStore — reads from the same SQLite the runtime writes to
    if "candle_store" not in st.session_state:
        st.session_state.candle_store = CandleStore()
    # Timeframe selection (persists between reruns; never triggers a new WS call)
    if "selected_tf_label" not in st.session_state:
        st.session_state.selected_tf_label = "30m"


_ensure_state()
s: Any                    = st.session_state.settings
runtime: BotRuntime       = st.session_state.runtime
candle_store: CandleStore = st.session_state.candle_store

snapshot: dict[str, Any] = runtime.snapshot()

# ── page header ────────────────────────────────────────────────────────────────

st.title("🤖 Delta SuperTrend Bot  —  Live 1m Feed")

colA, colB, colC = st.columns(3)
with colA:
    st.write("**WS Feed**")
    st.code("candlestick_1m  (raw ticks stored in SQLite)")
with colB:
    st.write("**Symbol**")
    st.code(s.symbol)
with colC:
    st.write("**Bot Status**")
    sv = _status_variant(snapshot["ws_status"])
    if sv == "error":
        st.error(snapshot["ws_status"])
    elif sv == "success":
        st.success(snapshot["ws_status"])
    else:
        st.warning(snapshot["ws_status"])

c1, c2, c3 = st.columns(3)
with c1:
    if st.button("▶ Start Bot", type="primary", disabled=snapshot["bot_running"]):
        sym = f"MARK:{s.symbol}" if s.use_mark_price else s.symbol
        runtime.start(symbol=sym)
        snapshot = runtime.snapshot()

with c2:
    if st.button("⏹ Stop Bot", disabled=not snapshot["bot_running"]):
        runtime.stop()
        snapshot = runtime.snapshot()

with c3:
    if st.button("☠ Kill Switch"):
        st.warning("Set KILL_SWITCH=true in .env and restart the app process.")

st.divider()

# ── health metrics ─────────────────────────────────────────────────────────────

h1, h2, h3, h4, h5 = st.columns(5)
h1.metric("Running",            "✅ Yes" if snapshot["bot_running"] else "❌ No")
h2.metric("Raw 1m Ticks (DB)",  snapshot.get("raw_tick_count", 0))
h3.metric("Session Ticks",      snapshot["candle_count"])
h4.metric("Last WS Tick",       _fmt_ts(snapshot["last_candle_received_at"]))
h5.metric("Last Trade",         snapshot["last_trade_action"])

# ── live position panel ────────────────────────────────────────────────────────

st.subheader("📊 Live Position & SuperTrend State")

pos_label = {1: "🟢 LONG", -1: "🔴 SHORT", 0: "⚪ FLAT"}.get(
    snapshot.get("current_position", 0), "⚪ FLAT"
)
dir_label = {1: "⬆ Bullish", -1: "⬇ Bearish"}.get(
    snapshot.get("current_direction"), "—"
)

p1, p2, p3, p4 = st.columns(4)
p1.metric("Position",         pos_label)
p2.metric("SuperTrend Value",
          f"{snapshot['current_supertrend']:.2f}" if snapshot.get("current_supertrend") else "—")
p3.metric("ST Direction",     dir_label)
p4.metric("Entry Price",
          f"{snapshot['entry_price']:.2f}" if snapshot.get("entry_price") else "—")

i1, i2, i3 = st.columns(3)
i1.caption(f"Started: {_fmt_ts(snapshot['started_at'])}")
i2.caption(f"Last Signal: {snapshot['last_signal']}")
i3.caption(f"Exchange Candle Time: {_fmt_ts(snapshot['last_candle_ts'])}")

st.divider()

# ── Chart section: TF selector → Refresh → Chart ─────────────────────────────

st.subheader("📈 OHLC Bars + SuperTrend Chart")

# Row 1: timeframe pills + refresh button side-by-side
tf_col, ref_col, info_col = st.columns([3, 1, 4])

with tf_col:
    selected_tf_label: str = st.radio(
        "Timeframe",
        options=list(TF_OPTIONS.keys()),
        horizontal=True,
        index=list(TF_OPTIONS.keys()).index(st.session_state.selected_tf_label),
        key="tf_radio",
    )
    st.session_state.selected_tf_label = selected_tf_label

tf_minutes = TF_OPTIONS[selected_tf_label]

with ref_col:
    st.write("")   # vertical alignment nudge
    refresh_clicked = st.button("🔄 Refresh", use_container_width=True)
    if refresh_clicked:
        # Re-read snapshot and recount DB rows on demand
        snapshot = runtime.snapshot()

with info_col:
    raw_count = candle_store.row_count(s.symbol.replace("MARK:", ""))
    if snapshot["bot_running"]:
        candle_ts = snapshot.get("last_candle_ts")
        last_str  = _fmt_ts(candle_ts) if candle_ts else "waiting…"
        st.caption(
            f"🟢 **Bot running** — Last 1m tick: `{last_str}` "
            f"— DB rows: `{raw_count}` — press **Refresh** to update chart"
        )
    else:
        st.caption(
            f"⏸️ Bot stopped — DB has `{raw_count}` stored 1m ticks — "
            f"press **Refresh** to redraw"
        )

# ── Resample from SQLite & draw chart ─────────────────────────────────────────
# Pure local read: candles.db → pandas resample — zero network I/O.
raw_symbol = s.symbol.replace("MARK:", "")
chart_df   = candle_store.resample(symbol=raw_symbol, tf_minutes=tf_minutes, limit=5000)

fig = _build_chart(
    resampled_df=chart_df,
    trades=snapshot["trades"],
    st_factor=s.supertrend_factor,
    atr_period=s.atr_period,
    tf_label=selected_tf_label,
)
st.plotly_chart(fig, use_container_width=True)

with st.expander("📖 Chart Legend"):
    st.markdown(
        """
| Element | Meaning |
|---|---|
| 🟢 Green candle | Bullish close |
| 🔴 Red candle | Bearish close |
| **Green ST line** (below price) | SuperTrend **bullish** — look for LONG entry |
| **Red ST line** (above price) | SuperTrend **bearish** — look for SHORT entry |
| ▲ Green triangle | **BUY** order placed |
| ▼ Red triangle | **SELL** order placed |
| ● Yellow circle | **EXIT** (long or short) |
| ✕ Grey cross | Failed / ignored order |

**Timeframe selector** resamples stored 1m SQLite ticks locally — no network calls.  
**New 1m tick:** arrives from Delta Exchange WS every ~30 s within each 1-minute bar.  
**Entry:** `close` crosses above SuperTrend (direction flips bullish)  
**Short:** `close` crosses below SuperTrend (direction flips bearish)  
**Exit:** trailing or fixed stop-loss hit
        """
    )

st.divider()

# ── runtime events ─────────────────────────────────────────────────────────────

st.subheader("🗒 Runtime Events")
events_df = pd.DataFrame(snapshot["recent_events"])
st.dataframe(events_df, use_container_width=True, hide_index=True)

# ── resampled candle table ─────────────────────────────────────────────────────

with st.expander(f"Recent {selected_tf_label} Candles (OHLCV + SuperTrend)"):
    if chart_df is not None and not chart_df.empty and len(chart_df) >= s.atr_period + 2:
        df_show = supertrend(chart_df.copy(), factor=s.supertrend_factor, atr_period=s.atr_period)
        df_show["time"] = pd.to_datetime(df_show["ts"], unit="s")
        cols = ["time", "open", "high", "low", "close", "volume", "supertrend", "direction"]
        st.dataframe(
            df_show[cols].tail(100).sort_values("time", ascending=False),
            use_container_width=True,
        )
    elif chart_df is not None and not chart_df.empty:
        df_show = chart_df.copy()
        df_show["time"] = pd.to_datetime(df_show["ts"], unit="s")
        st.dataframe(df_show.tail(100), use_container_width=True)
    else:
        st.info(f"No {selected_tf_label} bars yet. Start the bot and let 1m ticks accumulate.")

# ── trade history ──────────────────────────────────────────────────────────────

st.subheader("🧾 Trade History")
trades_df = snapshot["trades"]
if not trades_df.empty:
    trades_df = trades_df.copy()
    trades_df["time"] = pd.to_datetime(trades_df["ts"], unit="s")
    st.dataframe(trades_df.sort_values("ts", ascending=False), use_container_width=True)
else:
    st.info("No trades recorded yet.")

# ── API log tail ───────────────────────────────────────────────────────────────

with st.expander("🔌 Delta API / WebSocket Log"):
    st.caption(f"Log file: {API_LOG_PATH}")
    st.code(_tail_log(API_LOG_PATH), language="log")
