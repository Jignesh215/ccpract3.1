import pandas as pd
import streamlit as st

from core.config import load_settings
from core.delta_rest import DeltaRestClient, DeltaRestError


def _as_dataframe(rows):
    if isinstance(rows, list):
        return pd.DataFrame(rows)
    if isinstance(rows, dict):
        return pd.DataFrame([rows])
    return pd.DataFrame()

st.title("Account (Balances, Positions, P&L by Date)")

if "settings" not in st.session_state:
    st.session_state.settings = load_settings()

s = st.session_state.settings
rest = DeltaRestClient(s.api_key, s.api_secret, env=s.env)

col1, col2 = st.columns(2)

with col1:
    st.subheader("Wallet Balances")
    try:
        bal = rest.get_wallet_balances()
        rows = bal.get("result", [])
        meta = bal.get("meta", {})
        if meta:
            m1, m2 = st.columns(2)
            m1.metric("Net Equity", meta.get("net_equity", "-"))
            m2.metric("Robo Trading Equity", meta.get("robo_trading_equity", "-"))
        st.dataframe(_as_dataframe(rows), use_container_width=True)
    except DeltaRestError as e:
        st.error(str(e))

with col2:
    st.subheader("Open Positions")
    try:
        pos = rest.get_margined_positions()
        rows = pos.get("result", [])
        st.dataframe(_as_dataframe(rows), use_container_width=True)
    except DeltaRestError as e:
        st.error(str(e))

st.divider()

st.subheader("Account Trade History / P&L by date")
st.info(
    "Wire this to Delta fills/trades endpoints once you confirm the exact API for your account/product. "
    "This skeleton is intentionally safe."
)

st.caption("Private account endpoints require matching `ENV`, trading-enabled API keys, and a whitelisted IP on Delta.")
