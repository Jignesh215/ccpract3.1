from __future__ import annotations

from dataclasses import dataclass
import time
import pandas as pd

@dataclass
class Signal:
    ts: int
    action: str  # BUY | SELL | EXIT_LONG | EXIT_SHORT | HOLD
    price: float
    reason: str

class SupertrendTrailFixedSL:
    def __init__(self, trailing_points: float, fixed_sl_points: float, cooldown_seconds: int = 5):
        self.trailing_points = float(trailing_points)
        self.fixed_sl_points = float(fixed_sl_points)
        self.cooldown_seconds = int(cooldown_seconds)

        self.position = 0
        self.entry_price = None
        self.best_price = None
        self.last_trade_time = 0.0

    def _cooldown_ok(self) -> bool:
        return (time.time() - self.last_trade_time) >= self.cooldown_seconds

    def on_bar(self, df_with_st: pd.DataFrame) -> Signal:
        if len(df_with_st) < 3:
            last = df_with_st.iloc[-1]
            return Signal(int(last["ts"]), "HOLD", float(last["close"]), "warmup")

        prev = df_with_st.iloc[-2]
        last = df_with_st.iloc[-1]

        close_prev = float(prev["close"])
        close_now  = float(last["close"])
        st_prev    = float(prev["supertrend"])
        st_now     = float(last["supertrend"])

        ts = int(last["ts"])
        price = close_now

        long_condition = (close_prev <= st_prev) and (close_now > st_now)
        short_condition = (close_prev >= st_prev) and (close_now < st_now)

        if self.position == 1:
            self.best_price = max(self.best_price, price)
        elif self.position == -1:
            self.best_price = min(self.best_price, price)

        if self.position == 1:
            fixed_sl = self.entry_price - self.fixed_sl_points
            trail_sl = self.best_price - self.trailing_points
            stop = max(fixed_sl, trail_sl)
            if price <= stop and self._cooldown_ok():
                self.position = 0
                self.last_trade_time = time.time()
                return Signal(ts, "EXIT_LONG", price, f"stop_hit fixed={fixed_sl:.2f} trail={trail_sl:.2f} used={stop:.2f}")

        if self.position == -1:
            fixed_sl = self.entry_price + self.fixed_sl_points
            trail_sl = self.best_price + self.trailing_points
            stop = min(fixed_sl, trail_sl)
            if price >= stop and self._cooldown_ok():
                self.position = 0
                self.last_trade_time = time.time()
                return Signal(ts, "EXIT_SHORT", price, f"stop_hit fixed={fixed_sl:.2f} trail={trail_sl:.2f} used={stop:.2f}")

        if self.position == 0 and self._cooldown_ok():
            if long_condition:
                self.position = 1
                self.entry_price = price
                self.best_price = price
                self.last_trade_time = time.time()
                return Signal(ts, "BUY", price, "crossover close>supertrend")

            if short_condition:
                self.position = -1
                self.entry_price = price
                self.best_price = price
                self.last_trade_time = time.time()
                return Signal(ts, "SELL", price, "crossunder close<supertrend")

        return Signal(ts, "HOLD", price, "no_action")
