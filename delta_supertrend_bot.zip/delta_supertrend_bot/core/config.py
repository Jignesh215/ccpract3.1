import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    env: str
    log_level: str

    api_key: str
    api_secret: str

    symbol: str
    product_id: int
    use_mark_price: bool

    atr_period: int
    supertrend_factor: float
    trailing_points: float
    fixed_sl_points: float

    order_size: float
    order_type: str
    leverage: int

    timeframe: str

    max_position_abs: float
    cooldown_seconds: int
    kill_switch: bool

def _get_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name, str(default)).strip().lower()
    return v in ("1", "true", "yes", "y", "on")

def load_settings() -> Settings:
    api_key = os.getenv("DELTA_API_KEY", "").strip()
    api_secret = os.getenv("DELTA_API_SECRET", "").strip()
    if not api_key or not api_secret:
        raise RuntimeError("Missing DELTA_API_KEY / DELTA_API_SECRET in .env")

    return Settings(
        env=os.getenv("ENV", "prod").strip().lower(),
        log_level=os.getenv("LOG_LEVEL", "INFO").strip().upper(),

        api_key=api_key,
        api_secret=api_secret,

        symbol=os.getenv("SYMBOL", "BTCUSD").strip(),
        product_id=int(os.getenv("PRODUCT_ID", "0")),
        use_mark_price=_get_bool("USE_MARK_PRICE", False),

        atr_period=int(os.getenv("ATR_PERIOD", "10")),
        supertrend_factor=float(os.getenv("SUPERTREND_FACTOR", "1.0")),
        trailing_points=float(os.getenv("TRAILING_POINTS", "15000")),
        fixed_sl_points=float(os.getenv("FIXED_SL_POINTS", "4")),

        order_size=float(os.getenv("ORDER_SIZE", "1")),
        order_type=os.getenv("ORDER_TYPE", "market").strip().lower(),
        leverage=int(os.getenv("LEVERAGE", "1")),

        timeframe=os.getenv("TIMEFRAME", "4h").strip().lower(),

        max_position_abs=float(os.getenv("MAX_POSITION_ABS", "1")),
        cooldown_seconds=int(os.getenv("COOLDOWN_SECONDS", "10")),
        kill_switch=_get_bool("KILL_SWITCH", False),
    )
