from __future__ import annotations

import json
import threading
import time
from typing import Callable, Optional, Dict, Any

import websocket

from core.logger import get_api_logger

class DeltaWS:
    def __init__(self, env: str, on_candle: Callable[[Dict[str, Any]], None], on_status: Callable[[str], None]):
        self.env = env
        self.on_candle = on_candle
        self.on_status = on_status
        self.logger = get_api_logger()

        if env == "testnet":
            self.ws_url = "wss://socket-ind.testnet.deltaex.org"
        else:
            self.ws_url = "wss://socket.india.delta.exchange"

        self.ws: Optional[websocket.WebSocketApp] = None
        self.thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    def start(self, channel_name: str, symbols: list[str]) -> None:
        self._stop.clear()
        subscribed_text = f"WS subscribed: {channel_name} -> {', '.join(symbols)}"

        def _on_open(ws):
            self.logger.info("WS open | url=%s | channel=%s | symbols=%s", self.ws_url, channel_name, symbols)
            self.on_status("WS opened; subscribing...")
            payload = {
                "type": "subscribe",
                "payload": {"channels": [{"name": channel_name, "symbols": symbols}]},
            }
            self.logger.info("WS subscribe request | payload=%s", payload)
            ws.send(json.dumps(payload))

        def _on_message(ws, message: str):
            try:
                msg = json.loads(message)
            except Exception as e:
                self.logger.error("WS JSON parse error | error=%s | raw=%s", e, message[:500])
                self.on_status(f"WS message JSON parse error: {e} | raw={message[:200]}")
                return

            try:
                if isinstance(msg, dict) and msg.get("type") in ("subscriptions", "subscribed"):
                    self.logger.info("WS subscribe ack | payload=%s", msg)
                    self.on_status(subscribed_text)
                    return
                # Delta Exchange sends candlestick messages with type="candlestick_Xm"
                # and candle fields at the TOP LEVEL (no nested 'data' key).
                msg_type = msg.get("type", "")
                if msg_type.startswith("candlestick_") and "close" in msg:
                    candle_time = msg.get("candle_start_time") or msg.get("time")
                    self.logger.info(
                        "WS candle received | type=%s | candle_start_time=%s",
                        msg_type, candle_time,
                    )
                    # Wrap into {"data": msg} so on_candle handlers use msg["data"]
                    self.on_candle({"type": msg_type, "channel": msg_type, "data": msg})
            except Exception as e:
                self.logger.error("WS candle handler error | error=%s", e)
                self.on_status(f"WS candle handler error: {e}")

        def _on_error(ws, error):
            self.logger.error("WS error | error=%s", error)
            self.on_status(f"WS error: {error}")

        def _on_close(ws, code, reason):
            self.logger.warning("WS closed | code=%s | reason=%s", code, reason)
            self.on_status(f"WS closed: {code} | {reason}")

        self.ws = websocket.WebSocketApp(
            self.ws_url,
            on_open=_on_open,
            on_message=_on_message,
            on_error=_on_error,
            on_close=_on_close,
        )

        def runner():
            backoff = 1
            while not self._stop.is_set():
                try:
                    self.logger.info("WS connecting | url=%s", self.ws_url)
                    self.on_status("WS connecting...")
                    self.ws.run_forever(ping_interval=20, ping_timeout=10)
                except Exception as e:
                    self.logger.error("WS run_forever exception | error=%s", e)
                    self.on_status(f"WS run_forever exception: {e}")
                if self._stop.is_set():
                    break
                self.logger.warning("WS reconnecting | delay_seconds=%s", backoff)
                self.on_status(f"WS reconnecting in {backoff}s...")
                time.sleep(backoff)
                backoff = min(backoff * 2, 30)

        self.thread = threading.Thread(target=runner, daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self._stop.set()
        try:
            if self.ws:
                self.logger.info("WS stop requested")
                self.ws.close()
        except Exception:
            pass
