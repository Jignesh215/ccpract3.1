from __future__ import annotations

import pandas as pd

def true_range(high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low).abs(),
        (high - prev_close).abs(),
        (low - prev_close).abs()
    ], axis=1).max(axis=1)
    return tr

def atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int) -> pd.Series:
    tr = true_range(high, low, close)
    return tr.ewm(alpha=1/period, adjust=False).mean()

def supertrend(df: pd.DataFrame, factor: float, atr_period: int) -> pd.DataFrame:
    # Always work on a clean 0-based RangeIndex to make .iat[] safe
    df = df.reset_index(drop=True)

    high = df["high"].astype(float)
    low = df["low"].astype(float)
    close = df["close"].astype(float)

    hl2 = (high + low) / 2.0
    atr_val = atr(high, low, close, atr_period)

    upper_basic = hl2 + factor * atr_val
    lower_basic = hl2 - factor * atr_val

    n = len(df)
    upper_final = upper_basic.to_numpy(dtype=float).copy()
    lower_final = lower_basic.to_numpy(dtype=float).copy()
    direction   = [1] * n
    st          = [0.0] * n

    direction[0] = 1
    st[0]        = lower_final[0]

    for i in range(1, n):
        # upper band
        if upper_basic.iat[i] < upper_final[i - 1] or close.iat[i - 1] > upper_final[i - 1]:
            upper_final[i] = upper_basic.iat[i]
        else:
            upper_final[i] = upper_final[i - 1]

        # lower band
        if lower_basic.iat[i] > lower_final[i - 1] or close.iat[i - 1] < lower_final[i - 1]:
            lower_final[i] = lower_basic.iat[i]
        else:
            lower_final[i] = lower_final[i - 1]

        # direction
        if direction[i - 1] == 1:
            direction[i] = -1 if close.iat[i] < lower_final[i] else 1
        else:
            direction[i] = 1 if close.iat[i] > upper_final[i] else -1

        st[i] = lower_final[i] if direction[i] == 1 else upper_final[i]

    out = df.copy()
    out["supertrend"] = st
    out["direction"]  = direction
    return out
