from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import List
import pandas as pd

@dataclass
class TradeRow:
    ts: int
    symbol: str
    action: str
    price: float
    size: float
    order_id: str
    reason: str

class TradeStore:
    def __init__(self):
        self.trades: List[TradeRow] = []

    def add(self, row: TradeRow) -> None:
        self.trades.append(row)

    def df(self) -> pd.DataFrame:
        if not self.trades:
            return pd.DataFrame(columns=["ts","symbol","action","price","size","order_id","reason"])
        return pd.DataFrame([asdict(t) for t in self.trades])
