from __future__ import annotations

import json
import time
import requests
from typing import Any, Dict, Optional, Tuple

from core.delta_auth import generate_signature
from core.logger import get_api_logger

class DeltaRestError(RuntimeError):
    pass

class DeltaRestClient:
    def __init__(self, api_key: str, api_secret: str, env: str = "prod", timeout: Tuple[int,int]=(3, 20)):
        self.api_key = api_key
        self.api_secret = api_secret
        self.timeout = timeout
        self.logger = get_api_logger()

        if env == "testnet":
            self.base_url = "https://cdn-ind.testnet.deltaex.org"
        else:
            self.base_url = "https://api.india.delta.exchange"

    def _headers(self, method: str, path: str, query_string: str, payload: str) -> Dict[str, str]:
        timestamp = str(int(time.time()))
        signature_data = method + timestamp + path + query_string + payload
        signature = generate_signature(self.api_secret, signature_data)
        return {
            "api-key": self.api_key,
            "timestamp": timestamp,
            "signature": signature,
            "User-Agent": "delta-supertrend-bot",
            "Content-Type": "application/json",
        }

    def request(self, method: str, path: str, params: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        method = method.upper()
        url = f"{self.base_url}{path}"

        params = params or {}
        body = body or {}

        # Sort params alphabetically so the query string in the HMAC signature
        # always matches the query string actually sent by requests.
        sorted_params = dict(sorted(params.items())) if params else {}

        if sorted_params:
            qs = "&".join([f"{k}={sorted_params[k]}" for k in sorted_params])
            query_string = f"?{qs}"
        else:
            query_string = ""

        payload = json.dumps(body, separators=(",", ":")) if (method in ("POST","PUT") and body) else ""
        headers = self._headers(method, path, query_string, payload)
        started = time.time()

        self.logger.info(
            "REST request | method=%s | path=%s | params=%s | body=%s",
            method,
            path,
            params,
            body,
        )

        try:
            resp = requests.request(method, url, params=sorted_params, data=payload, headers=headers, timeout=self.timeout)
        except requests.Timeout as e:
            self.logger.error("REST timeout | method=%s | path=%s | error=%s", method, path, e)
            raise DeltaRestError(f"REST timeout calling {path}: {e}") from e
        except requests.RequestException as e:
            self.logger.error("REST request failure | method=%s | path=%s | error=%s", method, path, e)
            raise DeltaRestError(f"REST request error calling {path}: {e}") from e

        try:
            data = resp.json()
        except ValueError as e:
            self.logger.error(
                "REST invalid JSON | method=%s | path=%s | status=%s | body=%s",
                method,
                path,
                resp.status_code,
                resp.text[:500],
            )
            raise DeltaRestError(f"Non-JSON response from {path}: HTTP {resp.status_code} | {resp.text[:200]}") from e

        if resp.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False):
            self.logger.error(
                "REST error response | method=%s | path=%s | status=%s | elapsed_ms=%s | response=%s",
                method,
                path,
                resp.status_code,
                int((time.time() - started) * 1000),
                data,
            )
            raise DeltaRestError(f"Delta REST error {path}: HTTP {resp.status_code} | {data}")

        self.logger.info(
            "REST success | method=%s | path=%s | status=%s | elapsed_ms=%s",
            method,
            path,
            resp.status_code,
            int((time.time() - started) * 1000),
        )
        return data

    def get_products(self, symbol: str) -> Dict[str, Any]:
        return self.request("GET", "/v2/products", params={"symbol": symbol})

    def get_positions(self) -> Dict[str, Any]:
        return self.request("GET", "/v2/positions")

    def get_margined_positions(self, product_ids: Optional[list[int]] = None, contract_types: Optional[str] = None) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if product_ids:
            params["product_ids"] = ",".join(str(product_id) for product_id in product_ids)
        if contract_types:
            params["contract_types"] = contract_types
        return self.request("GET", "/v2/positions/margined", params=params)

    def get_wallet_balances(self) -> Dict[str, Any]:
        return self.request("GET", "/v2/wallet/balances")

    def get_history_candles(
        self,
        symbol: str,
        resolution: str = "4h",
        limit: int = 200,
    ) -> list[Dict[str, Any]]:
        """Fetch historical OHLCV candles from the Delta public candle REST endpoint.

        Delta Exchange candle endpoint:  GET /v2/history/candles
        This is a PUBLIC endpoint — no authentication required.
        Required params: symbol, resolution, start (unix seconds), end (unix seconds)
        NOTE: 'limit' param is not supported; we derive start/end from limit * resolution.
        Returns a list of candle dicts with keys: time, open, high, low, close, volume.

        Correct symbol for Solana perpetual: SOLUSD
        """
        # Resolution map: shorthand -> (Delta string, seconds per candle)
        _res_map = {
            "1m":  ("1m",  60),
            "3m":  ("3m",  180),
            "5m":  ("5m",  300),
            "15m": ("15m", 900),
            "30m": ("30m", 1800),
            "1h":  ("1h",  3600),
            "2h":  ("2h",  7200),
            "4h":  ("4h",  14400),
            "6h":  ("6h",  21600),
            "1d":  ("1d",  86400),
            "1w":  ("1w",  604800),
        }
        res_str, res_secs = _res_map.get(resolution, (resolution, 3600))

        end_ts = int(time.time())
        start_ts = end_ts - (limit * res_secs)

        public_url = f"{self.base_url}/v2/history/candles"
        public_params = {
            "symbol": symbol,
            "resolution": res_str,
            "start": str(start_ts),
            "end": str(end_ts),
        }

        self.logger.info(
            "Seeding history | symbol=%s | resolution=%s | limit=%s",
            symbol, res_str, limit,
        )

        try:
            resp = requests.get(
                public_url,
                params=public_params,
                headers={"User-Agent": "delta-supertrend-bot"},
                timeout=self.timeout,
            )
            data = resp.json()
        except Exception as e:
            self.logger.error("History candles request failed | error=%s", e)
            raise DeltaRestError(f"History candles request failed: {e}") from e

        if resp.status_code >= 400 or (isinstance(data, dict) and data.get("success") is False):
            self.logger.error(
                "History candles error | status=%s | response=%s",
                resp.status_code, data,
            )
            raise DeltaRestError(
                f"Delta REST error /v2/history/candles: HTTP {resp.status_code} | {data}"
            )

        self.logger.info(
            "History candles success | symbol=%s | candles=%s",
            symbol, len(data.get("result", [])),
        )
        # API returns {"result": [...candles...], "success": true}
        return data.get("result", [])

    def place_order_market(self, product_id: int, side: str, size: float) -> Dict[str, Any]:
        body = {
            "order_type": "market_order",
            "size": size,
            "side": side,
            "product_id": product_id,
        }
        return self.request("POST", "/v2/orders", body=body)

    def cancel_all_orders(self) -> Dict[str, Any]:
        return self.request("DELETE", "/v2/orders/all")
