from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path


LOG_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
PROJECT_ROOT = Path(__file__).resolve().parents[1]
API_LOG_PATH = PROJECT_ROOT / "api_call.log"


def _configure_logger(logger: logging.Logger, level: str, log_file: Path | None = None) -> logging.Logger:
    if logger.handlers:
        return logger

    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    formatter = logging.Formatter(LOG_FORMAT)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    if log_file is not None:
        file_handler = RotatingFileHandler(log_file, maxBytes=5_000_000, backupCount=3, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    logger.propagate = False
    return logger


def get_logger(name: str, level: str = "INFO") -> logging.Logger:
    logger = logging.getLogger(name)
    return _configure_logger(logger, level)


def get_api_logger(level: str = "INFO") -> logging.Logger:
    logger = logging.getLogger("delta.api")
    return _configure_logger(logger, level, API_LOG_PATH)
