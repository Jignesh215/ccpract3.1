import hmac
import hashlib

def generate_signature(api_secret: str, signature_data: str) -> str:
    mac = hmac.new(
        api_secret.encode("utf-8"),
        signature_data.encode("utf-8"),
        hashlib.sha256,
    )
    return mac.hexdigest()
