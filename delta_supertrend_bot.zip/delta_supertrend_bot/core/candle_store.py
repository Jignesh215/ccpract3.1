"""
candle_store.py
---------------
Lightweight SQLite-based local store for raw 1-minute WS candle ticks.

Design
------
* One table: `raw_candles` — stores every 1m tick received from the WebSocket.
  Each row is UPSERTED by (symbol, ts) so in-progress candles update in place.
* `resample(symbol, tf_minutes)` — aggregates the raw rows into any OHLCV
  timeframe (30m=30, 45m=45, 1h=60, 4h=240) purely in memory using pandas.
  No new network call is needed.
* Thread-safe: uses a `threading.Lock` around every SQLite write.
* DB file lives next to the project root as `candles.db`.
"""
from __future__ import annotations

import threading
from pathlib import Path
from typing import Any

import pandas as pd

try:
    import sqlite3
except ImportError:
    sqlite3 = None  # type: ignore

# DB path: <project_root>/candles.db
_DB_PATH = Path(__file__).resolve().parents[1] / "candles.db"

_CREATE_SQL = """
CREATE TABLE IF NOT EXISTS raw_candles (
    symbol  TEXT    NOT NULL,
    ts      INTEGER NOT NULL,   -- candle open time (unix seconds)
    open    REAL    NOT NULL,
    high    REAL    NOT NULL,
    low     REAL    NOT NULL,
    close   REAL    NOT NULL,
    volume  REAL    NOT NULL DEFAULT 0,
    PRIMARY KEY (symbol, ts)
);
"""

_UPSERT_SQL = """
INSERT INTO raw_candles (symbol, ts, open, high, low, close, volume)
VALUES (?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(symbol, ts) DO UPDATE SET
    high   = MAX(excluded.high,  raw_candles.high),
    low    = MIN(excluded.low,   raw_candles.low),
    close  = excluded.close,
    volume = excluded.volume;
"""


class CandleStore:
    """Thread-safe SQLite store for raw 1m candle ticks."""

    def __init__(self, db_path: Path = _DB_PATH) -> None:
        self._path = db_path
        self._lock = threading.Lock()
        self._init_db()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _connect(self):
        """Return a new SQLite connection (check_same_thread=False for safety)."""
        conn = sqlite3.connect(str(self._path), check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL;")   # concurrent reads while writing
        conn.execute("PRAGMA synchronous=NORMAL;")
        return conn

    def _init_db(self) -> None:
        with self._lock:
            conn = self._connect()
            conn.execute(_CREATE_SQL)
            conn.commit()
            conn.close()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def upsert(self, symbol: str, candle: dict[str, Any]) -> None:
        """Insert or update a single raw candle row (from WS tick)."""
        ts     = int(candle.get("time") or candle.get("candle_start_time", 0) or
                     candle.get("start_time") or candle.get("t", 0))
        # Delta WS sends candle_start_time in microseconds for some channels
        if ts > 1e12:
            ts = ts // 1_000_000
        open_  = float(candle.get("open",   0))
        high   = float(candle.get("high",   0))
        low    = float(candle.get("low",    0))
        close  = float(candle.get("close",  0))
        volume = float(candle.get("volume", 0))

        with self._lock:
            conn = self._connect()
            conn.execute(_UPSERT_SQL, (symbol, ts, open_, high, low, close, volume))
            conn.commit()
            conn.close()

    def get_raw(self, symbol: str, limit: int = 5000) -> pd.DataFrame:
        """Return raw 1m rows as a DataFrame, sorted by ts ascending."""
        with self._lock:
            conn = self._connect()
            df = pd.read_sql_query(
                "SELECT ts, open, high, low, close, volume "
                "FROM raw_candles WHERE symbol=? ORDER BY ts DESC LIMIT ?",
                conn,
                params=(symbol, limit),
            )
            conn.close()
        if df.empty:
            return df
        return df.sort_values("ts").reset_index(drop=True)

    def resample(self, symbol: str, tf_minutes: int, limit: int = 5000) -> pd.DataFrame:
        """
        Aggregate raw 1m rows into OHLCV bars of `tf_minutes` width.

        Returns a DataFrame with columns: ts, open, high, low, close, volume
        where `ts` is the bar open time (unix seconds).

        No network calls — purely local computation.
        """
        raw = self.get_raw(symbol, limit=limit)
        if raw.empty:
            return pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])

        # 1m is the native resolution — return raw rows directly, no aggregation needed
        if tf_minutes == 1:
            return raw[["ts", "open", "high", "low", "close", "volume"]].reset_index(drop=True)

        raw["dt"] = pd.to_datetime(raw["ts"], unit="s", utc=True)
        raw = raw.set_index("dt")

        rule = f"{tf_minutes}min"
        agg = raw.resample(rule, label="left", closed="left").agg(
            open=("open",   "first"),
            high=("high",   "max"),
            low= ("low",    "min"),
            close=("close", "last"),
            volume=("volume","sum"),
        ).dropna(subset=["open"])  # drop empty buckets

        agg = agg.reset_index()
        agg["ts"] = agg["dt"].astype("int64") // 10**9
        agg = agg[["ts", "open", "high", "low", "close", "volume"]].reset_index(drop=True)
        return agg

    def row_count(self, symbol: str) -> int:
        """Number of raw 1m rows stored for a symbol."""
        with self._lock:
            conn = self._connect()
            cur = conn.execute(
                "SELECT COUNT(*) FROM raw_candles WHERE symbol=?", (symbol,)
            )
            n = cur.fetchone()[0]
            conn.close()
        return n

    def clear(self, symbol: str | None = None) -> None:
        """Delete all rows for a symbol (or ALL rows if symbol is None)."""
        with self._lock:
            conn = self._connect()
            if symbol:
                conn.execute("DELETE FROM raw_candles WHERE symbol=?", (symbol,))
            else:
                conn.execute("DELETE FROM raw_candles")
            conn.commit()
            conn.close()
