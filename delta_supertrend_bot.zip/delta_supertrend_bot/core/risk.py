from __future__ import annotations

def check_kill_switch(kill_switch: bool) -> None:
    if kill_switch:
        raise RuntimeError("KILL_SWITCH=true — trading is disabled by configuration.")

def enforce_max_position(current_pos: float, max_abs: float) -> None:
    if abs(current_pos) > max_abs:
        raise RuntimeError(f"Risk limit breached: abs(position)={abs(current_pos)} > MAX_POSITION_ABS={max_abs}")
