from __future__ import annotations

import threading
import time
from collections import deque
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from core.delta_rest import DeltaRestClient, DeltaRestError
from core.delta_ws import DeltaWS
from core.indicators import supertrend
from core.logger import get_api_logger
from core.risk import check_kill_switch
from core.store import TradeRow, TradeStore
from core.strategy import SupertrendTrailFixedSL
from core.candle_store import CandleStore

# WS subscribes 1m candles — every tick is stored in SQLite.
# The dashboard resamples locally into 30m/45m/1h/4h without any new network call.
LIVE_CHANNEL = "candlestick_1m"
LIVE_RESOLUTION = "1m"
# Kept for backward-compat with any import in dashboard
SHOWCASE_CHANNEL = LIVE_CHANNEL
SHOWCASE_RESOLUTION = LIVE_RESOLUTION
# ST warm-up: need at least this many 1m bars before indicator is valid
ST_WARMUP_BARS = 20


def upsert_candle(df: pd.DataFrame, candle: dict[str, Any]) -> pd.DataFrame:
    raw_ts = (
        candle.get("candle_start_time") or
        candle.get("time") or
        candle.get("start_time") or
        candle.get("t") or
        0
    )
    ts = int(raw_ts)
    if ts > 1_000_000_000_000:
        ts = ts // 1_000_000
    row = {
        "ts": ts,
        "open": float(candle.get("open")),
        "high": float(candle.get("high")),
        "low": float(candle.get("low")),
        "close": float(candle.get("close")),
        "volume": float(candle.get("volume", 0.0)),
    }

    if df.empty:
        return pd.DataFrame([row])

    idx = df.index[df["ts"] == ts]
    if len(idx) > 0:
        df.loc[idx[0], ["open", "high", "low", "close", "volume"]] = [
            row["open"],
            row["high"],
            row["low"],
            row["close"],
            row["volume"],
        ]
        return df

    out = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    out = out.sort_values("ts").reset_index(drop=True)
    return out


class BotRuntime:
    def __init__(self, settings):
        self.settings = settings
        self.store = TradeStore()
        self.candle_db = CandleStore()                   # SQLite local store
        self.candles = pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])
        self.ws_status = "idle"
        self.bot_running = False
        self.rest = DeltaRestClient(settings.api_key, settings.api_secret, env=settings.env)
        self.strategy = SupertrendTrailFixedSL(
            trailing_points=settings.trailing_points,
            fixed_sl_points=settings.fixed_sl_points,
            cooldown_seconds=settings.cooldown_seconds,
        )
        self.ws: DeltaWS | None = None
        self._lock = threading.RLock()
        self.logger = get_api_logger()
        # Use static product_id from .env — avoids the /v2/products lookup that
        # can return wrong contracts (options/spreads) before the perpetual.
        if settings.product_id:
            self.product_id = settings.product_id
        else:
            self.product_id = None   # will fall back to API lookup if not set
        self.started_at: int | None = None
        self.last_status_at: int | None = None
        self.last_candle_ts: int | None = None
        self.last_candle_received_at: int | None = None
        self.candle_count = 0           # raw 1m ticks received this session
        self.raw_tick_count = 0         # total rows in SQLite (persists across restarts)
        self.last_signal = "WAITING"
        self.last_trade_at: int | None = None
        self.last_trade_action = "-"
        self.recent_events: deque[dict[str, str]] = deque(maxlen=50)
        # Supertrend / position telemetry for dashboard chart
        self.current_supertrend: float | None = None
        self.current_direction: int | None = None   # 1 = bullish, -1 = bearish
        self.current_position: int = 0               # 1 long / -1 short / 0 flat
        self.entry_price: float | None = None
        self.history_seeded = True   # no REST seeding — always ready

    def start(self, symbol: str) -> None:
        """Open the 1m WS live feed. Raw ticks are stored in SQLite as they arrive."""
        with self._lock:
            if self.bot_running:
                return
            self.started_at = int(time.time())
            self.last_status_at = self.started_at
            self.last_candle_ts = None
            self.last_candle_received_at = None
            self.candle_count = 0
            self.last_signal = "WAITING"
            self.last_trade_at = None
            self.last_trade_action = "-"
            # Report how many ticks are already in the local DB from previous sessions
            existing = self.candle_db.row_count(symbol.replace("MARK:", ""))
            self.raw_tick_count = existing
            self._record_event(
                f"Bot start | symbol={symbol} | channel={LIVE_CHANNEL} "
                f"| existing_db_rows={existing}"
            )
            self.ws_status = f"Connecting to {LIVE_CHANNEL} ({symbol})..."

        # Open the WebSocket live feed on 1m channel
        ws = DeltaWS(self.settings.env, on_candle=self._on_candle, on_status=self._on_status)
        with self._lock:
            self.ws = ws
            self.bot_running = True
        ws.start(channel_name=LIVE_CHANNEL, symbols=[symbol])
        self._record_event(f"WS started | channel={LIVE_CHANNEL} | symbol={symbol}")

    def stop(self) -> None:
        with self._lock:
            ws = self.ws
            self.ws = None
            self.bot_running = False
            self.ws_status = "stopped"
            self.last_status_at = int(time.time())
            self._record_event("Bot stopped")

        if ws:
            ws.stop()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "ws_status": self.ws_status,
                "bot_running": self.bot_running,
                "candles": self.candles.copy(),
                "trades": self.store.df().copy(),
                "started_at": self.started_at,
                "last_status_at": self.last_status_at,
                "last_candle_ts": self.last_candle_ts,
                "last_candle_received_at": self.last_candle_received_at,
                "candle_count": self.candle_count,
                "raw_tick_count": self.raw_tick_count,
                "last_signal": self.last_signal,
                "last_trade_at": self.last_trade_at,
                "last_trade_action": self.last_trade_action,
                "recent_events": list(self.recent_events),
                # Supertrend / position telemetry
                "current_supertrend": self.current_supertrend,
                "current_direction": self.current_direction,
                "current_position": self.current_position,
                "entry_price": self.entry_price,
                "history_seeded": self.history_seeded,
            }

    def _record_event(self, text: str) -> None:
        now = datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")
        self.recent_events.appendleft({"time": now, "event": text})

    def _on_status(self, text: str) -> None:
        with self._lock:
            if not self.bot_running and text.startswith("WS closed"):
                return
            self.ws_status = text
            self.last_status_at = int(time.time())
            self._record_event(text)

    def _resolve_product_id(self) -> int:
        with self._lock:
            if self.product_id is not None:
                self.logger.info("Using product_id=%s (from .env)", self.product_id)
                return self.product_id

        # Fallback: query the API only if PRODUCT_ID was not set in .env.
        # WARNING: /v2/products returns multiple contracts for a symbol
        # (perpetuals, options, spreads). We filter to contract_type=perpetual_futures.
        self.logger.warning(
            "PRODUCT_ID not set in .env — falling back to API lookup for symbol=%s. "
            "Set PRODUCT_ID in .env to avoid wrong contract selection.",
            self.settings.symbol,
        )
        resp = self.rest.get_products(self.settings.symbol)
        products = resp.get("result", [])
        # Prefer perpetual futures contract
        perps = [p for p in products if str(p.get("contract_type", "")).lower() == "perpetual_futures"]
        candidates = perps if perps else products
        if not candidates:
            raise RuntimeError(f"No product found for symbol={self.settings.symbol}")
        product_id = int(candidates[0]["id"])
        self.logger.info(
            "Resolved product_id=%s via API (contract_type=%s) for symbol=%s",
            product_id, candidates[0].get("contract_type"), self.settings.symbol,
        )
        with self._lock:
            self.product_id = product_id
        return product_id

    def _execute_trade(self, action: str, price: float, reason: str) -> None:
        settings = self.settings
        check_kill_switch(settings.kill_switch)
        product_id = self._resolve_product_id()

        try:
            if action == "BUY":
                response = self.rest.place_order_market(product_id, side="buy", size=settings.order_size)
            elif action in ("SELL", "EXIT_LONG"):
                response = self.rest.place_order_market(product_id, side="sell", size=settings.order_size)
            elif action == "EXIT_SHORT":
                response = self.rest.place_order_market(product_id, side="buy", size=settings.order_size)
            else:
                return

            order_id = str(response.get("result", {}).get("id", ""))
            row = TradeRow(
                ts=int(time.time()),
                symbol=settings.symbol,
                action=action,
                price=float(price),
                size=float(settings.order_size),
                order_id=order_id,
                reason=reason,
            )
            with self._lock:
                self.store.add(row)
                self.last_trade_at = row.ts
                self.last_trade_action = action
                self.last_signal = f"{action} | {reason}"
                self.ws_status = f"Trade executed: {action} @ {price}"
                self.last_status_at = row.ts
                self._record_event(f"Trade executed: {action} | price={price} | reason={reason}")

        except DeltaRestError as exc:
            row = TradeRow(
                ts=int(time.time()),
                symbol=settings.symbol,
                action=f"{action}_FAILED",
                price=float(price),
                size=float(settings.order_size),
                order_id="",
                reason=str(exc),
            )
            with self._lock:
                self.store.add(row)
                self.ws_status = f"TRADE ERROR: {exc}"
                self.last_trade_at = row.ts
                self.last_trade_action = f"{action}_FAILED"
                self.last_signal = f"{action}_FAILED | {reason}"
                self.last_status_at = row.ts
                self._record_event(f"Trade failed: {action} | error={exc}")

    def _on_candle(self, msg: dict[str, Any]) -> None:
        try:
            candle = msg["data"]
            # Delta sends candle_start_time in MICROSECONDS at the top level
            raw_ts = (
                candle.get("candle_start_time") or
                candle.get("time") or
                candle.get("start_time") or
                candle.get("t") or
                0
            )
            candle_ts = int(raw_ts)
            if candle_ts > 1_000_000_000_000:        # microseconds → seconds
                candle_ts = candle_ts // 1_000_000

            close_price = float(candle.get("close", 0))
            raw_symbol = self.settings.symbol.replace("MARK:", "")

            # ── 1. Persist raw 1m tick into SQLite ──
            self.candle_db.upsert(raw_symbol, {**candle, "time": candle_ts})

            with self._lock:
                # Keep a rolling in-memory 1m DataFrame for fast ST computation
                self.candles = upsert_candle(self.candles, {**candle, "time": candle_ts})
                df = self.candles.copy()
                self.candle_count += 1
                self.raw_tick_count = self.candle_db.row_count(raw_symbol)
                self.last_candle_ts = candle_ts
                self.last_candle_received_at = int(time.time())
                self.ws_status = (
                    f"Live: {self.settings.symbol} | 1m ticks={self.candle_count} "
                    f"| DB rows={self.raw_tick_count} | close={close_price:,.2f}"
                )
                self.last_status_at = self.last_candle_received_at

            self.logger.info(
                "WS 1m tick | symbol=%s | ts=%s | close=%s",
                raw_symbol, candle_ts, close_price,
            )

            # ── 2. Compute Supertrend on in-memory 1m bars (needs at least ST_WARMUP_BARS) ──
            if len(df) < ST_WARMUP_BARS:
                with self._lock:
                    self.last_signal = f"WARMING UP ({len(df)}/{ST_WARMUP_BARS} bars)"
                return

            df_st = supertrend(df, factor=self.settings.supertrend_factor, atr_period=self.settings.atr_period)
            last_row = df_st.iloc[-1]
            with self._lock:
                self.current_supertrend = float(last_row["supertrend"])
                self.current_direction = int(last_row["direction"])  # 1 bull / -1 bear

            # ── 3. Evaluate entry/exit signal ──
            sig = self.strategy.on_bar(df_st)

            with self._lock:
                self.last_signal = f"{sig.action} | {sig.reason}"
                self.current_position = self.strategy.position
                self.entry_price = self.strategy.entry_price
                if sig.action not in ("BUY", "SELL", "EXIT_LONG", "EXIT_SHORT"):
                    st_val = self.current_supertrend
                    dir_str = "▲ Bull" if self.current_direction == 1 else "▼ Bear"
                    self._record_event(
                        f"Signal: {sig.action} | ST={st_val:.2f} {dir_str} "
                        f"| close={close_price:.2f} | pos={self.current_position}"
                    )

            if sig.action in ("BUY", "SELL", "EXIT_LONG", "EXIT_SHORT"):
                self._execute_trade(sig.action, sig.price, sig.reason)

        except Exception as exc:
            with self._lock:
                self.ws_status = f"CANDLE PROCESS ERROR: {exc}"
                self.last_status_at = int(time.time())
                self._record_event(f"Candle process error: {exc}")
                self._record_event(f"Candle process error: {exc}")