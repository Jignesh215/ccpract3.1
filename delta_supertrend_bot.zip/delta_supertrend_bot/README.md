# Delta Supertrend Bot (Streamlit)

## Setup
1. Copy `.env.example` to `.env` and fill credentials.
2. Install deps:
   ```bash
   pip install -r requirements.txt
   ```
3. Run:
   ```bash
   streamlit run app.py
   ```

## Notes
- This is a skeleton intended for extension (trade history, P&L by date, native stop/trailing orders, persistence).
- Use testnet first.
- Account endpoints need the correct `ENV`, trading-enabled API keys, and the machine IP whitelisted on Delta.
- The dashboard now keeps websocket work off Streamlit threads to avoid `missing ScriptRunContext` warnings.
- Delta REST and WebSocket activity is written to `api_call.log` in the project root.
- A healthy bot lifecycle usually looks like `WS connecting...` -> `WS opened; subscribing...` -> `WS subscribed: ...` -> `Live: receiving candles (N)`.
